from distutils.core import setup

setup(
    name='Homework10',
    version="1.0",
    author="Siarhei Parkhomik",
    author_email="Siarhei_Parkhomik@epam.com",
    packages=["homework7_8"]
)
